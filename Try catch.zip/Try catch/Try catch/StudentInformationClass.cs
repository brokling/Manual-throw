﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Try_catch
{
    class StudentInformationClass
    {
        public int SetStudentNo = 0;
        public int SetContactNo = 0;
        public string SetProgram = " ";
        public string SetGender = " ";
        public string SetBirthday = " ";
        public string SetFullName = " ";
    }
}
